package pl.edu.utp.fitness.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import pl.edu.utp.fitness.domain.Zajecia;
import pl.edu.utp.fitness.repository.ZajeciaRepository;

import java.time.DayOfWeek;
import java.time.LocalTime;

/**
 * ============================================================================
 * INICJALIZATOR DANYCH TESTOWYCH.
 * ============================================================================
 * CommandLineRunner to specjalny interfejs Springa - kazdy bean tego typu
 * jest AUTOMATYCZNIE URUCHAMIANY RAZ, zaraz po starcie calej aplikacji.
 * Uzywamy go tutaj, zeby przy kazdym uruchomieniu programu baza danych
 * (H2 w pamieci - patrz application.properties) miala od razu kilka
 * przykladowych zajec, na ktorych mozna od razu potestowac dzialanie
 * calej aplikacji (bez recznego dodawania danych przez API/Swaggera).
 *
 * UWAGA: pojemnosc niektorych zajec jest CELOWO bardzo mala (np. 2-3 osoby),
 * a nie 20 jak w tresci zadania - dzieki temu latwo jest recznie / na
 * egzaminie zademonstrowac dzialanie listy REZERWOWEJ, bez koniecznosci
 * zakladania az 21 kont uzytkownikow. Algorytm dziala identycznie
 * niezaleznie od wielkosci limitu.
 */
@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner zaladujDaneTestowe(ZajeciaRepository zajeciaRepository) {
        return args -> {
            zajeciaRepository.save(new Zajecia("Joga", DayOfWeek.MONDAY, LocalTime.of(18, 0), 2));
            zajeciaRepository.save(new Zajecia("Zumba", DayOfWeek.TUESDAY, LocalTime.of(19, 0), 3));
            zajeciaRepository.save(new Zajecia("Spinning", DayOfWeek.WEDNESDAY, LocalTime.of(17, 30), 2));
            zajeciaRepository.save(new Zajecia("Pilates", DayOfWeek.THURSDAY, LocalTime.of(20, 0), 20));
            zajeciaRepository.save(new Zajecia("Trening funkcjonalny", DayOfWeek.FRIDAY, LocalTime.of(16, 0), 5));

            System.out.println("=========================================================");
            System.out.println(" Dane testowe zaladowane! Zaloguj sie i wejdz na /list");
            System.out.println(" Konta testowe: user/user123, admin/admin123,");
            System.out.println("                anna/anna123, piotr/piotr123");
            System.out.println("=========================================================");
        };
    }
}
