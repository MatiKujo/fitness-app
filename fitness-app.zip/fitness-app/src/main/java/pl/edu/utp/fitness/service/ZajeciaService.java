package pl.edu.utp.fitness.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pl.edu.utp.fitness.domain.Zajecia;
import pl.edu.utp.fitness.exception.ZajeciaNotFoundException;
import pl.edu.utp.fitness.repository.ZajeciaRepository;

import java.util.List;

/**
 * ============================================================================
 * SERWIS obslugujacy zajecia fitness (proste operacje CRUD:
 * Create, Read, Update, Delete).
 * ============================================================================
 * Tworzenie/usuwanie zajec to operacje ADMINISTRACYJNE - w SecurityConfig
 * oraz w kontrolerze REST sa one ograniczone tylko do roli ADMIN
 * (standardowy uzytkownik moze jedynie PRZEGLADAC liste zajec).
 */
@Service
public class ZajeciaService {

    private final ZajeciaRepository zajeciaRepository;

    public ZajeciaService(ZajeciaRepository zajeciaRepository) {
        this.zajeciaRepository = zajeciaRepository;
    }

    /** Zwraca liste WSZYSTKICH zajec dostepnych w systemie (caly "tydzien"). */
    @Transactional(readOnly = true)
    public List<Zajecia> pobierzWszystkie() {
        return zajeciaRepository.findAll();
    }

    /** Znajduje pojedyncze zajecia po ID lub rzuca wyjatek, jesli nie istnieja. */
    @Transactional(readOnly = true)
    public Zajecia znajdzPoId(Long id) {
        return zajeciaRepository.findById(id)
                .orElseThrow(() -> new ZajeciaNotFoundException(id));
    }

    /** Tworzy nowe zajecia (operacja tylko dla ADMINA - patrz SecurityConfig). */
    @Transactional
    public Zajecia utworz(Zajecia zajecia) {
        return zajeciaRepository.save(zajecia);
    }

    /** Usuwa zajecia o podanym ID (operacja tylko dla ADMINA). */
    @Transactional
    public void usun(Long id) {
        if (!zajeciaRepository.existsById(id)) {
            throw new ZajeciaNotFoundException(id);
        }
        zajeciaRepository.deleteById(id);
    }
}
