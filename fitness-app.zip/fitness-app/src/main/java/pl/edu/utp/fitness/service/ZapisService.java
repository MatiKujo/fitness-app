package pl.edu.utp.fitness.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pl.edu.utp.fitness.domain.StatusZapisu;
import pl.edu.utp.fitness.domain.Zajecia;
import pl.edu.utp.fitness.domain.Zapis;
import pl.edu.utp.fitness.exception.BrakUprawnienException;
import pl.edu.utp.fitness.exception.DuplicateZapisException;
import pl.edu.utp.fitness.exception.ZajeciaNotFoundException;
import pl.edu.utp.fitness.exception.ZapisNotFoundException;
import pl.edu.utp.fitness.repository.ZajeciaRepository;
import pl.edu.utp.fitness.repository.ZapisRepository;

import java.util.List;

/**
 * ============================================================================
 * SERWIS = tutaj mieszka CALA LOGIKA BIZNESOWA aplikacji (algorytm kolejki).
 * ============================================================================
 * @Service oznacza klase "warstwy serwisowej" - Spring automatycznie tworzy
 * jeden obiekt (bean) tej klasy i "wstrzykuje" go (Dependency Injection)
 * tam, gdzie jest potrzebny (np. do kontrolerow REST).
 *
 * Kontrolery (REST/Web) NIE powinny zawierac logiki biznesowej - ich zadaniem
 * jest tylko odbierac zadania HTTP i przekazywac je dalej, do serwisu.
 * Caly "mozg" algorytmu kolejkowania jest tutaj.
 */
@Service
public class ZapisService {

    private final ZapisRepository zapisRepository;
    private final ZajeciaRepository zajeciaRepository;

    /**
     * Wstrzykiwanie zaleznosci przez KONSTRUKTOR (rekomendowany sposob
     * w Springu - latwiejszy do testowania niz np. adnotacja @Autowired
     * na polu). Spring sam dostarczy tutaj gotowe obiekty repozytoriow.
     */
    public ZapisService(ZapisRepository zapisRepository, ZajeciaRepository zajeciaRepository) {
        this.zapisRepository = zapisRepository;
        this.zajeciaRepository = zajeciaRepository;
    }

    /**
     * ========================================================================
     * ZAPISANIE SIE NA ZAJECIA (algorytm zarzadzania kolejka - czesc 1).
     * ========================================================================
     * @Transactional oznacza, ze cala metoda wykonuje sie w JEDNEJ transakcji
     * bazodanowej - albo WSZYSTKIE zmiany w bazie sie zapisza, albo (w razie
     * bledu) ZADNA z nich (rollback). To bardzo wazne przy operacjach na
     * kolejce, zeby nie "rozjechac" pozycji w kolejce w razie awarii w trakcie.
     *
     * Logika:
     *  1. Sprawdz, czy zajecia istnieja.
     *  2. Sprawdz, czy uzytkownik nie jest juz zapisany (zakaz duplikatow).
     *  3. Policz, ile osob jest juz na liscie GLOWNEJ.
     *  4. Jesli jest jeszcze wolne miejsce (licznik < pojemnoscMax)
     *       -> nowa osoba trafia na liste GLOWNA.
     *     W przeciwnym razie (limit osiagniety, np. 20/20)
     *       -> nowa osoba trafia na liste REZERWOWA, na KONIEC kolejki
     *          (pozycja = aktualna liczba rezerwowych + 1).
     *          Przyklad z tresci zadania: 21. osoba przy limicie 20
     *          dostaje pozycje rezerwowa nr 1.
     */
    @Transactional
    public Zapis zapiszSie(Long zajeciaId, String username) {
        Zajecia zajecia = zajeciaRepository.findById(zajeciaId)
                .orElseThrow(() -> new ZajeciaNotFoundException(zajeciaId));

        // Krok 2: zabraniamy zapisania sie 2 razy na te same zajecia.
        zapisRepository.findByZajeciaAndUsername(zajecia, username)
                .ifPresent(z -> {
                    throw new DuplicateZapisException(username);
                });

        // Krok 3: ile osob jest aktualnie na liscie GLOWNEJ?
        long liczbaNaGlownej = zapisRepository.countByZajeciaAndStatus(zajecia, StatusZapisu.GLOWNA);

        Zapis nowyZapis;
        if (liczbaNaGlownej < zajecia.getPojemnoscMax()) {
            // Krok 4a: jest wolne miejsce -> od razu lista GLOWNA.
            nowyZapis = new Zapis(username, zajecia, StatusZapisu.GLOWNA, null);
        } else {
            // Krok 4b: brak miejsc -> lista REZERWOWA, pozycja na koncu kolejki.
            long liczbaRezerwowych = zapisRepository.countByZajeciaAndStatus(zajecia, StatusZapisu.REZERWOWA);
            int nowaPozycja = (int) liczbaRezerwowych + 1;
            nowyZapis = new Zapis(username, zajecia, StatusZapisu.REZERWOWA, nowaPozycja);
        }

        return zapisRepository.save(nowyZapis);
    }

    /**
     * ========================================================================
     * WYPISANIE SIE Z ZAJEC (algorytm zarzadzania kolejka - czesc 2).
     * ========================================================================
     * To jest wymagany w zadaniu endpoint: "POST do wypisania sie z zajec,
     * ktory uruchamia logike kolejkowania".
     *
     * Logika:
     *  1. Znajdz zapis, ktory ma byc usuniety.
     *  2. Sprawdz uprawnienia - uzytkownik moze wypisac TYLKO SIEBIE
     *     (chyba, ze jest administratorem).
     *  3. Zapamietaj, jaki mial status (GLOWNA czy REZERWOWA) PRZED usunieciem.
     *  4. Usun zapis z bazy.
     *  5. JESLI zwolnione miejsce bylo na liscie GLOWNEJ:
     *       - znajdz PIERWSZA osobe z listy REZERWOWEJ (najmniejsza pozycja),
     *       - "wciagnij" ja na liste GLOWNA (status = GLOWNA, pozycja = null),
     *       - przesun wszystkich pozostalych rezerwowych o "jedno miejsce
     *         do przodu" w kolejce (reindeksacja pozycji 1, 2, 3...).
     *     JESLI wypisala sie osoba z listy REZERWOWEJ:
     *       - trzeba tylko przeindeksowac pozostale pozycje w kolejce,
     *         zeby nie bylo "dziury" (np. z 1,3,4 zrobic 1,2,3).
     *
     * @param zapisId    id zapisu do usuniecia
     * @param username   login osoby wykonujacej zadanie (z tokenu/sesji)
     * @param isAdmin    czy wykonujacy ma role ADMIN (admin moze wypisac kazdego)
     */
    @Transactional
    public void wypiszSie(Long zapisId, String username, boolean isAdmin) {
        Zapis zapis = zapisRepository.findById(zapisId)
                .orElseThrow(() -> new ZapisNotFoundException(zapisId));

        // Krok 2: standardowy uzytkownik moze wypisac WYLACZNIE samego siebie.
        if (!isAdmin && !zapis.getUsername().equals(username)) {
            throw new BrakUprawnienException("Nie mozesz wypisac innego uzytkownika z zajec");
        }

        Zajecia zajecia = zapis.getZajecia();
        StatusZapisu statusPrzedUsunieciem = zapis.getStatus();

        // Krok 4: usuwamy zapis z bazy.
        zapisRepository.delete(zapis);

        if (statusPrzedUsunieciem == StatusZapisu.GLOWNA) {
            // Zwolnilo sie miejsce na liscie GLOWNEJ -> "wciagamy" pierwsza
            // osobe z kolejki rezerwowej (jesli ktos w niej czeka).
            promujPierwszaOsobeZRezerwy(zajecia);
        }

        // Niezaleznie od tego, kto sie wypisal - zawsze upewniamy sie,
        // ze pozycje w kolejce rezerwowej sa "ciagle" (1, 2, 3, ... bez dziur).
        przeindeksujListeRezerwowa(zajecia);
    }

    /**
     * Znajduje osobe na 1. miejscu listy rezerwowej (najmniejsza wartosc
     * pozycjaWKolejce) i "przenosi" ja na liste glowna, zwalniajac jej
     * miejsce w kolejce rezerwowej.
     */
    private void promujPierwszaOsobeZRezerwy(Zajecia zajecia) {
        List<Zapis> listaRezerwowa =
                zapisRepository.findByZajeciaAndStatusOrderByPozycjaWKolejceAsc(zajecia, StatusZapisu.REZERWOWA);

        if (!listaRezerwowa.isEmpty()) {
            Zapis pierwszyWKolejce = listaRezerwowa.get(0);
            pierwszyWKolejce.setStatus(StatusZapisu.GLOWNA);
            pierwszyWKolejce.setPozycjaWKolejce(null); // na liscie glownej nie ma pozycji w kolejce
            zapisRepository.save(pierwszyWKolejce);
        }
        // Jesli lista rezerwowa byla pusta - po prostu zwalnia sie 1 wolne
        // miejsce na zajeciach i nikt nie jest promowany. To poprawne zachowanie.
    }

    /**
     * Przelicza od nowa pozycje wszystkich osob na liscie rezerwowej danych
     * zajec, tak aby byly to kolejne liczby bez "dziur": 1, 2, 3, 4...
     * Wywolywane po kazdej zmianie (wypisaniu kogokolwiek), bo usuniecie
     * osoby z pozycji np. 2 zostawiloby "dziure" (1, _, 3, 4).
     */
    private void przeindeksujListeRezerwowa(Zajecia zajecia) {
        List<Zapis> listaRezerwowa =
                zapisRepository.findByZajeciaAndStatusOrderByPozycjaWKolejceAsc(zajecia, StatusZapisu.REZERWOWA);

        int nowaPozycja = 1;
        for (Zapis z : listaRezerwowa) {
            // Aktualizujemy tylko wtedy, gdy pozycja faktycznie sie zmienila
            // (drobna optymalizacja - mniej niepotrzebnych zapytan UPDATE do bazy).
            if (!Integer.valueOf(nowaPozycja).equals(z.getPozycjaWKolejce())) {
                z.setPozycjaWKolejce(nowaPozycja);
                zapisRepository.save(z);
            }
            nowaPozycja++;
        }
    }

    /** Zwraca wszystkie zapisy danego uzytkownika (do widoku "Moje zapisy"). */
    @Transactional(readOnly = true)
    public List<Zapis> pobierzZapisyUzytkownika(String username) {
        return zapisRepository.findByUsername(username);
    }

    /** Zwraca liste osob na liscie glownej danych zajec (np. do podgladu admina). */
    @Transactional(readOnly = true)
    public List<Zapis> pobierzListeGlowna(Zajecia zajecia) {
        return zapisRepository.findByZajeciaAndStatusOrderByPozycjaWKolejceAsc(zajecia, StatusZapisu.GLOWNA);
    }

    /** Zwraca liste osob na liscie rezerwowej danych zajec, posortowana wg pozycji. */
    @Transactional(readOnly = true)
    public List<Zapis> pobierzListeRezerwowa(Zajecia zajecia) {
        return zapisRepository.findByZajeciaAndStatusOrderByPozycjaWKolejceAsc(zajecia, StatusZapisu.REZERWOWA);
    }
}
