package pl.edu.utp.fitness.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.*;
import pl.edu.utp.fitness.domain.Zapis;
import pl.edu.utp.fitness.service.ZapisService;

import java.util.List;

/**
 * ============================================================================
 * KONTROLER REST dla zasobu "Zapis" - SERCE ZADANIA.
 * ============================================================================
 * Tutaj znajduje sie m.in. wymagany w tresci zadania:
 * "Endpoint POST do wypisania sie z zajec, ktory uruchamia logike
 *  kolejkowania" -> patrz metoda wypiszSie() ponizej.
 *
 * Wszystkie metody w tej klasie wymagaja bycia ZALOGOWANYM (patrz
 * SecurityConfig: anyRequest().authenticated()). Standardowy uzytkownik
 * (rola USER) moze zapisywac sie / wypisywac WYLACZNIE we wlasnym imieniu -
 * login pobieramy z obiektu Authentication (czyli z sesji zalogowanego
 * uzytkownika), a NIE z parametru podanego recznie przez klienta -
 * dzieki temu user nie moze "podszyc sie" pod kogos innego.
 */
@RestController
@RequestMapping("/api/zapisy")
@Tag(name = "Zapisy", description = "Zapisywanie / wypisywanie sie na zajecia oraz kolejka rezerwowa")
public class ZapisRestController {

    private final ZapisService zapisService;

    public ZapisRestController(ZapisService zapisService) {
        this.zapisService = zapisService;
    }

    /**
     * POST /api/zapisy/zajecia/{zajeciaId}
     * Zapisuje AKTUALNIE ZALOGOWANEGO uzytkownika na wskazane zajecia.
     * Jesli jest wolne miejsce -> trafia na liste GLOWNA.
     * Jesli miejsc brak -> trafia na koniec listy REZERWOWEJ.
     */
    @PostMapping("/zajecia/{zajeciaId}")
    @Operation(summary = "Zapisz sie na zajecia (automatycznie: lista glowna lub rezerwowa)")
    public ResponseEntity<Zapis> zapiszSie(@PathVariable Long zajeciaId, Authentication authentication) {
        String username = authentication.getName();
        Zapis zapis = zapisService.zapiszSie(zajeciaId, username);
        return ResponseEntity.status(HttpStatus.CREATED).body(zapis);
    }

    /**
     * ========================================================================
     * POST /api/zapisy/{zapisId}/wypisz
     * ========================================================================
     * TO JEST ENDPOINT WYMAGANY W TRESCI ZADANIA:
     * "Endpoint POST do wypisania sie z zajec, ktory uruchamia logike
     *  kolejkowania."
     *
     * Po wywolaniu:
     *  - zapis danej osoby jest usuwany,
     *  - jesli osoba byla na liscie GLOWNEJ, cala logika kolejkowania
     *    (patrz ZapisService.wypiszSie) automatycznie "wciaga" pierwsza
     *    osobe z listy rezerwowej na zwolnione miejsce.
     *
     * Standardowy uzytkownik moze wypisac TYLKO SWOJ WLASNY zapis
     * (sprawdzane w serwisie na podstawie username z sesji). Administrator
     * moze wypisac dowolny zapis (np. w razie potrzeby porzadkowania listy).
     */
    @PostMapping("/{zapisId}/wypisz")
    @Operation(summary = "Wypisz sie z zajec - uruchamia logike kolejki (wciagniecie osoby z listy rezerwowej)")
    public ResponseEntity<Void> wypiszSie(@PathVariable Long zapisId, Authentication authentication) {
        String username = authentication.getName();
        boolean isAdmin = czyMaRoleAdmin(authentication);

        zapisService.wypiszSie(zapisId, username, isAdmin);
        return ResponseEntity.noContent().build();
    }

    /**
     * GET /api/zapisy/moje
     * Zwraca liste wszystkich zapisow aktualnie zalogowanego uzytkownika
     * (przydatne do zbudowania sekcji "Moje rezerwacje" w interfejsie WWW).
     */
    @GetMapping("/moje")
    @Operation(summary = "Pobierz liste zapisow aktualnie zalogowanego uzytkownika")
    public ResponseEntity<List<Zapis>> mojeZapisy(Authentication authentication) {
        return ResponseEntity.ok(zapisService.pobierzZapisyUzytkownika(authentication.getName()));
    }

    /**
     * Pomocnicza metoda sprawdzajaca, czy zalogowany uzytkownik posiada
     * role ADMIN (przegladajac liste jego "uprawnien" / GrantedAuthority).
     */
    private boolean czyMaRoleAdmin(Authentication authentication) {
        for (GrantedAuthority authority : authentication.getAuthorities()) {
            if (authority.getAuthority().equals("ROLE_ADMIN")) {
                return true;
            }
        }
        return false;
    }
}
