package pl.edu.utp.fitness.domain;

/**
 * ============================================================================
 * ENUM (typ wyliczeniowy) - reprezentuje mozliwe statusy zapisu na zajecia.
 * ============================================================================
 * Enum to specjalny typ w Javie, ktory pozwala zdefiniowac skonczony,
 * zamkniety zbior mozliwych wartosci. Zamiast trzymac status jako String
 * (np. "glowna", "GLOWNA", "Glowna" - latwo o literowke!), uzywamy enuma,
 * dzieki czemu kompilator "pilnuje" nas i mozemy uzyc tylko tych dwoch wartosci.
 */
public enum StatusZapisu {

    /** Uczestnik jest na liscie GLOWNEJ - ma zagwarantowane miejsce na zajeciach. */
    GLOWNA,

    /** Uczestnik jest na liscie REZERWOWEJ - czeka w kolejce, az zwolni sie miejsce. */
    REZERWOWA

}
