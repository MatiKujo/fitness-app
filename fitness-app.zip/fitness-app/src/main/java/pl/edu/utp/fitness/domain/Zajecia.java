package pl.edu.utp.fitness.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.DayOfWeek;
import java.time.LocalTime;

/**
 * ============================================================================
 * ENCJA (ang. Entity) = klasa reprezentujaca jedna tabele w bazie danych.
 * ============================================================================
 * Adnotacja @Entity mowi Springowi/Hibernate: "stworz dla tej klasy tabele
 * w bazie danych, a kazdy obiekt tej klasy to bedzie jeden wiersz w tabeli".
 *
 * Ta klasa reprezentuje POJEDYNCZE ZAJECIA FITNESS, np.:
 *   "Joga, Poniedzialek, 18:00, max 20 osob"
 */
@Entity
@Table(name = "zajecia")
public class Zajecia {

    /**
     * Klucz glowny (ID) - unikalny numer identyfikujacy kazdy wiersz w tabeli.
     * @Id            -> mowi, ze to jest klucz glowny
     * @GeneratedValue -> baza danych sama generuje kolejne numery (1, 2, 3, ...)
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Nazwa/typ zajec, np. "Joga", "Zumba", "Spinning", "Pilates". */
    @NotBlank(message = "Nazwa zajec nie moze byc pusta")
    @Column(nullable = false)
    private String nazwa;

    /** Dzien tygodnia, w ktorym odbywaja sie zajecia (np. MONDAY, TUESDAY...). */
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DayOfWeek dzienTygodnia;

    /** Godzina rozpoczecia zajec, np. 18:00. */
    @NotNull
    @Column(nullable = false)
    private LocalTime godzinaRozpoczecia;

    /**
     * Maksymalna liczba osob na liscie GLOWNEJ. Gdy zostanie osiagnieta,
     * kolejne osoby zapisuja sie na liste REZERWOWA.
     * (W tresci zadania: "zajecia maja max 20 osob" - tutaj to pole).
     */
    @NotNull
    @Min(value = 1, message = "Pojemnosc musi byc wieksza od 0")
    @Column(nullable = false)
    private Integer pojemnoscMax;

    /**
     * Pusty konstruktor jest WYMAGANY przez JPA/Hibernate - to Hibernate
     * "za kulisami" tworzy obiekty tej klasy, gdy odczytuje dane z bazy,
     * i musi miec mozliwosc stworzenia "pustego" obiektu.
     */
    public Zajecia() {
    }

    /** Wygodny konstruktor do tworzenia nowych zajec w kodzie (np. w testach). */
    public Zajecia(String nazwa, DayOfWeek dzienTygodnia, LocalTime godzinaRozpoczecia, Integer pojemnoscMax) {
        this.nazwa = nazwa;
        this.dzienTygodnia = dzienTygodnia;
        this.godzinaRozpoczecia = godzinaRozpoczecia;
        this.pojemnoscMax = pojemnoscMax;
    }

    // ========================================================================
    // GETTERY I SETTERY
    // Sa potrzebne, zeby inne klasy (np. Hibernate, Thymeleaf, kontrolery REST
    // zamieniajace obiekty na JSON) mogly odczytac/ustawic wartosci prywatnych
    // pol tej klasy. Pola sa "private", wiec bezposredni dostep z zewnatrz jest
    // zablokowany - trzeba korzystac z tych publicznych metod (enkapsulacja).
    // ========================================================================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public DayOfWeek getDzienTygodnia() {
        return dzienTygodnia;
    }

    public void setDzienTygodnia(DayOfWeek dzienTygodnia) {
        this.dzienTygodnia = dzienTygodnia;
    }

    public LocalTime getGodzinaRozpoczecia() {
        return godzinaRozpoczecia;
    }

    public void setGodzinaRozpoczecia(LocalTime godzinaRozpoczecia) {
        this.godzinaRozpoczecia = godzinaRozpoczecia;
    }

    public Integer getPojemnoscMax() {
        return pojemnoscMax;
    }

    public void setPojemnoscMax(Integer pojemnoscMax) {
        this.pojemnoscMax = pojemnoscMax;
    }
}
