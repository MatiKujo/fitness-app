package pl.edu.utp.fitness.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import pl.edu.utp.fitness.domain.Zajecia;
import pl.edu.utp.fitness.domain.Zapis;
import pl.edu.utp.fitness.service.ZajeciaService;
import pl.edu.utp.fitness.service.ZapisService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * ============================================================================
 * KONTROLER WWW (nie REST!) - zwraca strony HTML wygenerowane przez Thymeleaf,
 * a NIE dane JSON.
 * ============================================================================
 * Roznica miedzy @Controller a @RestController:
 *  - @RestController -> kazda metoda zwraca dane (JSON) bezposrednio do klienta
 *  - @Controller      -> metoda zwraca NAZWE SZABLONU HTML (String), a Spring
 *                        + Thymeleaf renderuja z niego pelna strone WWW,
 *                        wstawiajac w odpowiednie miejsca dane z "Model"
 *
 * Ten kontroler obsluguje interfejs uzytkownika przegladany w przegladarce:
 * liste zajec w tygodniu wraz z przyciskami "Zapisz sie" / "Wypisz sie".
 */
@Controller
public class WebController {

    private final ZajeciaService zajeciaService;
    private final ZapisService zapisService;

    public WebController(ZajeciaService zajeciaService, ZapisService zapisService) {
        this.zajeciaService = zajeciaService;
        this.zapisService = zapisService;
    }

    /**
     * GET /  ->  po prostu przekierowanie na glowna liste zajec.
     */
    @GetMapping("/")
    public String stronaGlowna() {
        return "redirect:/list";
    }

    /**
     * GET /list
     * Glowny widok aplikacji: tabela ze wszystkimi zajeciami w tygodniu,
     * z liczba wolnych miejsc oraz przyciskiem "Zapisz sie" (jesli user
     * jeszcze nie jest zapisany) lub "Wypisz sie" (jesli juz jest, z podana
     * pozycja w kolejce, gdy jest na liscie rezerwowej).
     */
    @GetMapping("/list")
    public String listaZajec(Model model, Authentication authentication) {
        String username = authentication.getName();

        List<Zajecia> wszystkieZajecia = zajeciaService.pobierzWszystkie();
        List<Zapis> mojeZapisy = zapisService.pobierzZapisyUzytkownika(username);

        // Budujemy liste "widokow" (ZajeciaWidok) - dla kazdych zajec liczymy
        // ile jest zajetych/wolnych miejsc oraz sprawdzamy, czy zalogowany
        // uzytkownik jest juz na nie zapisany.
        List<ZajeciaWidok> widoki = new ArrayList<>();
        for (Zajecia zajecia : wszystkieZajecia) {
            long liczbaGlownych = zapisService.pobierzListeGlowna(zajecia).size();
            long liczbaRezerwowych = zapisService.pobierzListeRezerwowa(zajecia).size();

            // Szukamy, czy wsrod "moich zapisow" jest jakis dotyczacy tych wlasnie zajec.
            Optional<Zapis> mojZapisNaTeZajecia = mojeZapisy.stream()
                    .filter(z -> z.getZajecia().getId().equals(zajecia.getId()))
                    .findFirst();

            widoki.add(new ZajeciaWidok(zajecia, liczbaGlownych, liczbaRezerwowych,
                    mojZapisNaTeZajecia.orElse(null)));
        }

        model.addAttribute("listaZajec", widoki);
        model.addAttribute("username", username);
        model.addAttribute("isAdmin", czyMaRoleAdmin(authentication));

        // Nazwa zwracana z metody = nazwa pliku szablonu w src/main/resources/templates
        // (bez rozszerzenia .html) -> renderowany bedzie plik templates/list.html
        return "list";
    }

    /**
     * POST /web/zapisz/{zajeciaId}
     * Obsluga przycisku "Zapisz sie" z formularza HTML. Zwykly formularz HTML
     * potrafi wysylac tylko zadania GET/POST (nie umie np. PUT), dlatego
     * uzywamy tutaj POST, a cala logike biznesowa i tak deleguje do tego
     * samego serwisu (ZapisService), co REST API.
     */
    @PostMapping("/web/zapisz/{zajeciaId}")
    public String zapiszSieZFormularza(@PathVariable Long zajeciaId, Authentication authentication) {
        zapisService.zapiszSie(zajeciaId, authentication.getName());
        // Po wykonaniu akcji przekierowujemy z powrotem na liste (wzorzec
        // Post-Redirect-Get - zapobiega przypadkowemu ponownemu wyslaniu
        // formularza przy odswiezeniu strony przez uzytkownika).
        return "redirect:/list";
    }

    /**
     * POST /web/wypisz/{zapisId}
     * Obsluga przycisku "Wypisz sie" - wywoluje dokladnie ta sama metode
     * serwisowa z logika kolejkowania, co endpoint REST
     * POST /api/zapisy/{zapisId}/wypisz.
     */
    @PostMapping("/web/wypisz/{zapisId}")
    public String wypiszSieZFormularza(@PathVariable Long zapisId, Authentication authentication) {
        boolean isAdmin = czyMaRoleAdmin(authentication);
        zapisService.wypiszSie(zapisId, authentication.getName(), isAdmin);
        return "redirect:/list";
    }

    private boolean czyMaRoleAdmin(Authentication authentication) {
        for (GrantedAuthority authority : authentication.getAuthorities()) {
            if (authority.getAuthority().equals("ROLE_ADMIN")) {
                return true;
            }
        }
        return false;
    }
}
