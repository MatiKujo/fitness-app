package pl.edu.utp.fitness.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.edu.utp.fitness.domain.StatusZapisu;
import pl.edu.utp.fitness.domain.Zajecia;
import pl.edu.utp.fitness.domain.Zapis;

import java.util.List;
import java.util.Optional;

/**
 * ============================================================================
 * REPOZYTORIUM dla encji Zapis.
 * ============================================================================
 * Oprocz gotowych metod z JpaRepository, dopisujemy tutaj WLASNE metody.
 * Sztuczka Spring Data JPA polega na tym, ze wystarczy odpowiednio NAZWAC
 * metode (wg konwencji: findBy... / countBy... + nazwy pol z encji), a Spring
 * SAM zbuduje zapytanie SQL na podstawie samej nazwy metody!
 * Nie trzeba pisac zadnej implementacji - tylko sygnature metody.
 */
public interface ZapisRepository extends JpaRepository<Zapis, Long> {

    /**
     * Zwraca liste zapisow dla danych zajec o danym statusie (GLOWNA/REZERWOWA),
     * posortowana rosnaco po pozycji w kolejce.
     * Odpowiednik SQL:
     *   SELECT * FROM zapisy WHERE zajecia_id = ? AND status = ?
     *   ORDER BY pozycja_w_kolejce ASC
     *
     * Wykorzystywane m.in. do znalezienia PIERWSZEJ osoby z listy rezerwowej,
     * ktora ma "wskoczyc" na zwolnione miejsce.
     */
    List<Zapis> findByZajeciaAndStatusOrderByPozycjaWKolejceAsc(Zajecia zajecia, StatusZapisu status);

    /**
     * Liczy, ile osob ma juz dany status (GLOWNA/REZERWOWA) na danych zajeciach.
     * Uzywane do sprawdzenia, czy jest jeszcze wolne miejsce na liscie glownej
     * (count < pojemnoscMax) oraz do wyliczenia kolejnej wolnej pozycji w kolejce.
     */
    long countByZajeciaAndStatus(Zajecia zajecia, StatusZapisu status);

    /**
     * Sprawdza, czy dany uzytkownik jest JUZ zapisany na dane zajecia
     * (niezaleznie od statusu) - zapobiega podwojnemu zapisowi tej samej osoby.
     */
    Optional<Zapis> findByZajeciaAndUsername(Zajecia zajecia, String username);

    /**
     * Zwraca wszystkie zapisy danego uzytkownika (do sekcji "Moje zapisy" w UI).
     */
    List<Zapis> findByUsername(String username);
}
