package pl.edu.utp.fitness.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * ============================================================================
 * ENCJA Zapis = laczy uzytkownika z konkretnymi zajeciami.
 * ============================================================================
 * To jest "serce" calego zadania - kazdy wiersz w tej tabeli oznacza,
 * ze dany uzytkownik (username) zapisal sie na dane zajecia (zajecia)
 * i ma okreslony status: GLOWNA (ma pewne miejsce) albo REZERWOWA (czeka
 * w kolejce na pozycji pozycjaWKolejce).
 *
 * Przyklad wierszy w tabeli "zapisy":
 *  id | username | zajecia_id | status    | pozycja_w_kolejce | data_zapisu
 *  1  | anna     | 1          | GLOWNA    | null              | 2026-07-01 10:00
 *  2  | piotr    | 1          | GLOWNA    | null              | 2026-07-01 10:05
 *  3  | kasia    | 1          | REZERWOWA | 1                 | 2026-07-01 10:10   <- pierwsza w kolejce
 *  4  | marek    | 1          | REZERWOWA | 2                 | 2026-07-01 10:15
 */
@Entity
@Table(name = "zapisy")
public class Zapis {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Login uzytkownika, ktory sie zapisal (np. "user", "anna123").
     * Dla uproszczenia projektu (na potrzeby egzaminu) NIE tworzymy osobnej
     * tabeli/encji "Uzytkownik" - login pobieramy prosto z danych logowania
     * Spring Security (patrz: SecurityConfig - uzytkownicy "user" i "admin").
     * W prawdziwym systemie produkcyjnym byloby tu @ManyToOne do encji User.
     */
    @Column(nullable = false)
    private String username;

    /**
     * Powiazanie Wiele-Do-Jednego: WIELE zapisow moze wskazywac na JEDNE zajecia.
     * FetchType.LAZY = dane o zajeciach sa pobierane z bazy dopiero wtedy,
     * gdy naprawde ich potrzebujemy (optymalizacja wydajnosci).
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "zajecia_id", nullable = false)
    private Zajecia zajecia;

    /** Status zapisu: GLOWNA lub REZERWOWA (patrz enum StatusZapisu). */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusZapisu status;

    /**
     * Pozycja w kolejce rezerwowej (1, 2, 3, ...).
     * Wartosc NULL oznacza, ze uczestnik jest na liscie GLOWNEJ (nie czeka
     * w kolejce, wiec pozycja go nie dotyczy).
     * Im mniejsza liczba, tym wczesniej dana osoba "wskoczy" na liste glowna.
     */
    @Column(name = "pozycja_w_kolejce")
    private Integer pozycjaWKolejce;

    /** Data i godzina zapisania sie - przydatne np. do sortowania / audytu. */
    @Column(nullable = false)
    private LocalDateTime dataZapisu;

    public Zapis() {
    }

    public Zapis(String username, Zajecia zajecia, StatusZapisu status, Integer pozycjaWKolejce) {
        this.username = username;
        this.zajecia = zajecia;
        this.status = status;
        this.pozycjaWKolejce = pozycjaWKolejce;
        this.dataZapisu = LocalDateTime.now();
    }

    // ========================================================================
    // GETTERY I SETTERY
    // ========================================================================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Zajecia getZajecia() {
        return zajecia;
    }

    public void setZajecia(Zajecia zajecia) {
        this.zajecia = zajecia;
    }

    public StatusZapisu getStatus() {
        return status;
    }

    public void setStatus(StatusZapisu status) {
        this.status = status;
    }

    public Integer getPozycjaWKolejce() {
        return pozycjaWKolejce;
    }

    public void setPozycjaWKolejce(Integer pozycjaWKolejce) {
        this.pozycjaWKolejce = pozycjaWKolejce;
    }

    public LocalDateTime getDataZapisu() {
        return dataZapisu;
    }

    public void setDataZapisu(LocalDateTime dataZapisu) {
        this.dataZapisu = dataZapisu;
    }
}
