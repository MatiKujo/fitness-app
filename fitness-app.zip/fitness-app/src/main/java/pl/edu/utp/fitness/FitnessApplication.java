package pl.edu.utp.fitness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * ============================================================================
 * KLASA STARTOWA APLIKACJI.
 * ============================================================================
 * To jest "punkt wejscia" - klasa z metoda main(), ktora uruchamia caly
 * program. Adnotacja @SpringBootApplication to "3 w 1":
 *  - @Configuration     -> ta klasa moze definiowac konfiguracje
 *  - @EnableAutoConfiguration -> Spring Boot sam konfiguruje baze danych,
 *                                serwer WWW, Thymeleaf itd. na podstawie tego,
 *                                jakie biblioteki (zaleznosci) sa w pom.xml
 *  - @ComponentScan     -> Spring sam znajduje wszystkie nasze klasy oznaczone
 *                          jako @Service, @Controller, @Repository itd.
 *                          w tym pakiecie i podpakietach
 *
 * Aby uruchomic aplikacje:
 *   mvn spring-boot:run
 * albo uruchom po prostu ta klase (metode main) w swoim IDE (IntelliJ/Eclipse).
 *
 * Po starcie wejdz w przegladarce na:
 *   http://localhost:8080/list          -> strona WWW z lista zajec
 *   http://localhost:8080/swagger-ui.html -> dokumentacja REST API
 *   http://localhost:8080/h2-console    -> podglad bazy danych
 * ============================================================================
 */
@SpringBootApplication
public class FitnessApplication {

    public static void main(String[] args) {
        // Ta jedna linijka uruchamia caly serwer WWW (wbudowany Tomcat) razem
        // z baza danych i wszystkimi naszymi klasami.
        SpringApplication.run(FitnessApplication.class, args);
    }
}
