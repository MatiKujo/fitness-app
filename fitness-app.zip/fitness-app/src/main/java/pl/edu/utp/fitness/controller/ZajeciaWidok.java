package pl.edu.utp.fitness.controller;

import pl.edu.utp.fitness.domain.Zajecia;
import pl.edu.utp.fitness.domain.Zapis;

/**
 * ============================================================================
 * KLASA POMOCNICZA (tzw. DTO / ViewModel) - NIE jest to encja bazodanowa!
 * ============================================================================
 * Sluzy WYLACZNIE do wygodnego przekazania danych do strony HTML (Thymeleaf).
 * Laczy w sobie:
 *  - dane o samych zajeciach (nazwa, godzina, pojemnosc),
 *  - policzona liczbe wolnych miejsc,
 *  - informacje o tym, czy AKTUALNIE ZALOGOWANY uzytkownik jest juz zapisany
 *    na te zajecia i z jakim statusem (zeby w widoku HTML pokazac wlasciwy
 *    przycisk: "Zapisz sie" albo "Wypisz sie (lista glowna)" albo
 *    "Wypisz sie (rezerwa, pozycja 2)").
 *
 * Dzieki takiemu opakowaniu logika wyswietlania jest prosta - szablon HTML
 * nie musi sam liczyc wolnych miejsc ani szukac zapisu uzytkownika.
 */
public class ZajeciaWidok {

    private final Zajecia zajecia;
    private final long liczbaZapisanychGlownych;
    private final long liczbaOsobNaRezerwie;
    private final Zapis mojZapis; // null, jesli zalogowany user nie jest zapisany na te zajecia

    public ZajeciaWidok(Zajecia zajecia, long liczbaZapisanychGlownych, long liczbaOsobNaRezerwie, Zapis mojZapis) {
        this.zajecia = zajecia;
        this.liczbaZapisanychGlownych = liczbaZapisanychGlownych;
        this.liczbaOsobNaRezerwie = liczbaOsobNaRezerwie;
        this.mojZapis = mojZapis;
    }

    public Zajecia getZajecia() {
        return zajecia;
    }

    public long getLiczbaZapisanychGlownych() {
        return liczbaZapisanychGlownych;
    }

    public long getLiczbaOsobNaRezerwie() {
        return liczbaOsobNaRezerwie;
    }

    /** Ile jest jeszcze wolnych miejsc na liscie glownej. */
    public long getWolneMiejsca() {
        return zajecia.getPojemnoscMax() - liczbaZapisanychGlownych;
    }

    public Zapis getMojZapis() {
        return mojZapis;
    }

    /** Czy zalogowany uzytkownik jest juz zapisany (glowna lub rezerwa)? */
    public boolean isCzyZapisany() {
        return mojZapis != null;
    }

    /** Czy zalogowany uzytkownik jest zapisany na liscie GLOWNEJ? */
    public boolean isNaLiscieGlownej() {
        return mojZapis != null && "GLOWNA".equals(mojZapis.getStatus().name());
    }

    /** Czy zalogowany uzytkownik jest zapisany na liscie REZERWOWEJ? */
    public boolean isNaLiscieRezerwowej() {
        return mojZapis != null && "REZERWOWA".equals(mojZapis.getStatus().name());
    }
}
