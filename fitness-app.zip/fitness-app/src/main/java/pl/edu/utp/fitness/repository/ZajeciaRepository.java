package pl.edu.utp.fitness.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.edu.utp.fitness.domain.Zajecia;

/**
 * ============================================================================
 * REPOZYTORIUM = warstwa odpowiedzialna za rozmowe z baza danych.
 * ============================================================================
 * Wystarczy, ze interfejs "rozszerza" (extends) JpaRepository, a Spring Data
 * JPA SAM w locie generuje implementacje (gotowy kod) z metodami takimi jak:
 *   - findAll()      -> zwraca wszystkie zajecia
 *   - findById(id)    -> znajdz zajecia po ID
 *   - save(obiekt)   -> zapisz nowe zajecia / zaktualizuj istniejace
 *   - deleteById(id) -> usun zajecia
 *
 * JpaRepository<Zajecia, Long> oznacza:
 *   Zajecia -> typ encji, ktora obslugujemy
 *   Long    -> typ pola @Id w tej encji
 *
 * Nie musimy pisac ani jednej linijki SQL - Spring robi to za nas!
 */
public interface ZajeciaRepository extends JpaRepository<Zajecia, Long> {
    // Na razie nie potrzebujemy dodatkowych, wlasnych zapytan -
    // gotowe metody z JpaRepository (findAll, findById, save, delete...)
    // w zupelnosci wystarczaja do obslugi zajec.
}
