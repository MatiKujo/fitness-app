package pl.edu.utp.fitness.exception;

/** Wyjatek rzucany, gdy zapis (rezerwacja) o podanym ID nie istnieje. */
public class ZapisNotFoundException extends RuntimeException {
    public ZapisNotFoundException(Long id) {
        super("Nie znaleziono zapisu o id: " + id);
    }
}
