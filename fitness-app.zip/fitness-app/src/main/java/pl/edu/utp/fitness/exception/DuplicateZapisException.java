package pl.edu.utp.fitness.exception;

/**
 * Wyjatek rzucany, gdy uzytkownik probuje zapisac sie po raz DRUGI
 * na te same zajecia, na ktore juz jest zapisany (na liscie glownej
 * lub rezerwowej).
 */
public class DuplicateZapisException extends RuntimeException {
    public DuplicateZapisException(String username) {
        super("Uzytkownik '" + username + "' jest juz zapisany na te zajecia");
    }
}
