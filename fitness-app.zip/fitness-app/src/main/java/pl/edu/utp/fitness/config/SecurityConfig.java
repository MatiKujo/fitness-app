package pl.edu.utp.fitness.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

/**
 * ============================================================================
 * KONFIGURACJA BEZPIECZENSTWA (Spring Security).
 * ============================================================================
 * Tutaj definiujemy:
 *  1. Jacy uzytkownicy moga sie zalogowac (na potrzeby egzaminu/demo -
 *     uzytkownicy "na sztywno" w pamieci, bez osobnej tabeli w bazie).
 *  2. Jakie role maja dostep do jakich adresow URL (kto co moze robic).
 *
 * ROLE W SYSTEMIE:
 *  - USER  -> standardowy uzytkownik: moze TYLKO zapisywac sie / wypisywac
 *             z zajec (zgodnie z wymaganiem w tresci zadania).
 *  - ADMIN -> administrator: dodatkowo moze TWORZYC i USUWAC zajecia.
 *             (Admin posiada obie role, wiec moze rowniez zapisywac sie
 *              na zajecia tak jak zwykly user).
 *
 * DANE TESTOWE DO LOGOWANIA (do wpisania w oknie logowania w przegladarce):
 *   login: user   haslo: user123    -> rola USER
 *   login: admin  haslo: admin123   -> role USER + ADMIN
 *   login: anna   haslo: anna123    -> rola USER (dodatkowy user do testow kolejki)
 *   login: piotr  haslo: piotr123   -> rola USER (dodatkowy user do testow kolejki)
 * ============================================================================
 */
@Configuration
@EnableMethodSecurity // wlacza obsluge adnotacji @PreAuthorize na metodach kontrolerow
public class SecurityConfig {

    /**
     * Definiuje, ktore adresy URL wymagaja logowania, a ktore sa publiczne,
     * oraz jaka role jest potrzebna do danej operacji.
     * Kolejnosc regul MA ZNACZENIE - Spring sprawdza je od gory do dolu
     * i stosuje PIERWSZA pasujaca regule.
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // CSRF (Cross-Site Request Forgery) wylaczamy dla uproszczenia
                // projektu na potrzeby egzaminu/nauki - dzieki temu formularze
                // POST z prostego HTML-a oraz wywolania z Swaggera dzialaja
                // "z automatu", bez dolaczania specjalnego tokenu.
                // UWAGA: w prawdziwej aplikacji produkcyjnej CSRF powinno
                // pozostac WLACZONE dla formularzy WWW!
                .csrf(csrf -> csrf.disable())

                // Pozwalamy wyswietlac konsole H2 w ramce <iframe> (domyslnie
                // Spring Security tego zabrania - inaczej konsola H2 by nie dzialala).
                .headers(headers -> headers.frameOptions(HeadersConfigurer.FrameOptionsConfig::disable))

                .authorizeHttpRequests(auth -> auth
                        // --- ZASOBY PUBLICZNE (dostepne bez logowania) ---
                        .requestMatchers(
                                "/css/**", "/js/**", "/images/**",           // pliki statyczne
                                "/h2-console/**",                             // konsola bazy danych (do podgladu)
                                "/swagger-ui/**", "/swagger-ui.html",         // interfejs Swaggera
                                "/v3/api-docs/**",                            // specyfikacja OpenAPI (JSON)
                                "/login", "/error"
                        ).permitAll()

                        // --- OPERACJE ADMINISTRACYJNE: tworzenie / usuwanie zajec ---
                        // Standardowy uzytkownik NIE moze tworzyc ani kasowac zajec -
                        // zgodnie z wymaganiem: "Standardowi uzytkownicy moga tylko
                        // sie zapisywac / wypisywac".
                        .requestMatchers("POST", "/api/zajecia/**").hasRole("ADMIN")
                        .requestMatchers("DELETE", "/api/zajecia/**").hasRole("ADMIN")

                        // --- Wszystko inne (lista zajec, zapisywanie sie, strony WWW) ---
                        // wymaga bycia zalogowanym (jakakolwiek rola: USER lub ADMIN).
                        .anyRequest().authenticated()
                )

                // Logowanie klasycznym formularzem HTML (Spring Security sam
                // generuje prosta strone logowania pod adresem /login).
                .formLogin(form -> form
                        .defaultSuccessUrl("/list", true) // po zalogowaniu przekieruj na liste zajec
                        .permitAll()
                )

                // Wylogowanie pod adresem /logout (obsluzone automatycznie przez Spring Security).
                .logout(logout -> logout
                        .logoutSuccessUrl("/login")
                        .permitAll()
                )

                // HTTP Basic Auth - dodatkowa metoda logowania, wygodna przy
                // testowaniu REST API np. przez Swaggera / Postmana / curl
                // (mozna podac login:haslo bezposrednio w zadaniu HTTP).
                .httpBasic(httpBasic -> {});

        return http.build();
    }

    /**
     * Definiuje uzytkownikow "na sztywno" w pamieci (In-Memory).
     * W prawdziwym systemie dane logowania trzymalibysmy w bazie danych
     * (osobna tabela "uzytkownicy" + hashowane hasla), ale dla potrzeb
     * egzaminu/demo wystarczy prosta wersja w pamieci.
     */
    @Bean
    public InMemoryUserDetailsManager userDetailsService(PasswordEncoder encoder) {
        UserDetails user = User.builder()
                .username("user")
                .password(encoder.encode("user123"))
                .roles("USER")
                .build();

        UserDetails admin = User.builder()
                .username("admin")
                .password(encoder.encode("admin123"))
                .roles("USER", "ADMIN") // admin ma obie role
                .build();

        // Dodatkowi uzytkownicy - przydatni do RECZNEGO testowania dzialania
        // kolejki rezerwowej (mozna zalogowac sie na kilka kont w roznych
        // przegladarkach / oknach incognito i sprawdzic, jak dziala kolejkowanie).
        UserDetails anna = User.builder()
                .username("anna")
                .password(encoder.encode("anna123"))
                .roles("USER")
                .build();

        UserDetails piotr = User.builder()
                .username("piotr")
                .password(encoder.encode("piotr123"))
                .roles("USER")
                .build();

        return new InMemoryUserDetailsManager(user, admin, anna, piotr);
    }

    /**
     * Koder hasel - hasla NIGDY nie sa trzymane "jawnym tekstem", zawsze
     * w postaci zaszyfrowanej (hashowanej). BCrypt to standardowy, bezpieczny
     * algorytm hashowania hasel uzywany w Spring Security.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
