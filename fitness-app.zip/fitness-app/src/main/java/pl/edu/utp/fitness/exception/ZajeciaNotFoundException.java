package pl.edu.utp.fitness.exception;

/**
 * Wlasny (customowy) wyjatek - rzucany, gdy ktos probuje odwolac sie
 * do zajec o ID, ktore nie istnieje w bazie danych.
 * "extends RuntimeException" oznacza, ze jest to wyjatek NIEKONTROLOWANY
 * (unchecked) - nie trzeba go deklarowac w "throws" ani na sile lapac.
 */
public class ZajeciaNotFoundException extends RuntimeException {
    public ZajeciaNotFoundException(Long id) {
        super("Nie znaleziono zajec o id: " + id);
    }
}
