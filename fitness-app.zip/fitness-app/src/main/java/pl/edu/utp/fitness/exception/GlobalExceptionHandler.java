package pl.edu.utp.fitness.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * ============================================================================
 * GLOBALNY HANDLER WYJATKOW dla calego REST API.
 * ============================================================================
 * @RestControllerAdvice sprawia, ze metody z tej klasy "przechwytuja"
 * wyjatki rzucone w KTORYMKOLWIEK kontrolerze REST w calej aplikacji.
 * Dzieki temu:
 *  - nie musimy pisac bloku try/catch w kazdym kontrolerze osobno,
 *  - klient (np. przegladarka, Swagger, aplikacja mobilna) dostaje ladny,
 *    czytelny komunikat JSON z odpowiednim kodem HTTP zamiast brzydkiego
 *    "500 Internal Server Error" ze stack trace'em.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /** Zajecia o podanym ID nie istnieja -> HTTP 404 Not Found. */
    @ExceptionHandler(ZajeciaNotFoundException.class)
    public ResponseEntity<Object> handleZajeciaNotFound(ZajeciaNotFoundException ex) {
        return buildResponse(HttpStatus.NOT_FOUND, ex.getMessage());
    }

    /** Zapis o podanym ID nie istnieje -> HTTP 404 Not Found. */
    @ExceptionHandler(ZapisNotFoundException.class)
    public ResponseEntity<Object> handleZapisNotFound(ZapisNotFoundException ex) {
        return buildResponse(HttpStatus.NOT_FOUND, ex.getMessage());
    }

    /** Proba podwojnego zapisu na te same zajecia -> HTTP 409 Conflict. */
    @ExceptionHandler(DuplicateZapisException.class)
    public ResponseEntity<Object> handleDuplicate(DuplicateZapisException ex) {
        return buildResponse(HttpStatus.CONFLICT, ex.getMessage());
    }

    /** Brak uprawnien do danej operacji -> HTTP 403 Forbidden. */
    @ExceptionHandler({BrakUprawnienException.class, AccessDeniedException.class})
    public ResponseEntity<Object> handleBrakUprawnien(RuntimeException ex) {
        return buildResponse(HttpStatus.FORBIDDEN, ex.getMessage());
    }

    /**
     * Pomocnicza metoda budujaca jednolita, czytelna strukture odpowiedzi
     * bledu w formacie JSON, np.:
     * {
     *   "timestamp": "2026-07-04T10:15:30",
     *   "status": 404,
     *   "error": "Nie znaleziono zajec o id: 99"
     * }
     */
    private ResponseEntity<Object> buildResponse(HttpStatus status, String message) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", status.value());
        body.put("error", message);
        return new ResponseEntity<>(body, status);
    }
}
