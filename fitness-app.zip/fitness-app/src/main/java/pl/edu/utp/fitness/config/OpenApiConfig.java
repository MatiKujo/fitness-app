package pl.edu.utp.fitness.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * ============================================================================
 * KONFIGURACJA SWAGGERA (OpenAPI) - opisuje, jak ma wygladac strona
 * dokumentacji API pod adresem: http://localhost:8080/swagger-ui.html
 * ============================================================================
 * Biblioteka springdoc-openapi SAMA skanuje wszystkie nasze kontrolery
 * (@RestController) i generuje z nich dokumentacje - my musimy tylko
 * dorzucic ladny "naglowek" (tytul, opis, dane kontaktowe) oraz informacje
 * o tym, ze API wymaga logowania (HTTP Basic Auth), zeby w Swagger UI
 * pojawil sie przycisk "Authorize" do wpisania loginu/hasla.
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Fitness - System Rezerwacji Zajec API")
                        .version("1.0.0")
                        .description("REST API do zarzadzania zapisami na zajecia fitness "
                                + "wraz z automatyczna obsluga listy rezerwowej (kolejki). "
                                + "Domyslni uzytkownicy do testow: user/user123, admin/admin123.")
                        .contact(new Contact().name("UTP - projekt zaliczeniowy")))
                // Dodajemy schemat bezpieczenstwa "basicAuth", zeby w Swagger UI
                // pojawil sie przycisk umozliwiajacy zalogowanie sie loginem/haslem
                // i testowanie zabezpieczonych endpointow bezposrednio z przegladarki.
                .addSecurityItem(new SecurityRequirement().addList("basicAuth"))
                .schemaRequirement("basicAuth", new SecurityScheme()
                        .type(SecurityScheme.Type.HTTP)
                        .scheme("basic"));
    }
}
