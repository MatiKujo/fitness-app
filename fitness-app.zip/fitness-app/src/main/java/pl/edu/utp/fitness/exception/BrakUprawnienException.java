package pl.edu.utp.fitness.exception;

/**
 * Wyjatek rzucany, gdy uzytkownik probuje wypisac (skasowac) zapis,
 * ktory NIE nalezy do niego (np. "user" probuje wypisac "admina").
 * Standardowy uzytkownik moze wypisywac WYLACZNIE swoje wlasne zapisy.
 */
public class BrakUprawnienException extends RuntimeException {
    public BrakUprawnienException(String message) {
        super(message);
    }
}
