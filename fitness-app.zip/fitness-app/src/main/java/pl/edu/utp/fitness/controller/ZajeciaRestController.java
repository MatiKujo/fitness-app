package pl.edu.utp.fitness.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pl.edu.utp.fitness.domain.Zajecia;
import pl.edu.utp.fitness.service.ZajeciaService;

import java.util.List;

/**
 * ============================================================================
 * KONTROLER REST dla zasobu "Zajecia".
 * ============================================================================
 * @RestController = @Controller + @ResponseBody, czyli kazda metoda
 * automatycznie zwraca dane w formacie JSON (a nie np. widok HTML).
 *
 * @RequestMapping("/api/zajecia") - wszystkie metody w tej klasie sa
 * dostepne pod adresem zaczynajacym sie od /api/zajecia.
 *
 * @Tag - adnotacja Swaggera, grupuje endpointy w dokumentacji pod wspolna nazwa.
 */
@RestController
@RequestMapping("/api/zajecia")
@Tag(name = "Zajecia", description = "Zarzadzanie lista zajec fitness")
public class ZajeciaRestController {

    private final ZajeciaService zajeciaService;

    public ZajeciaRestController(ZajeciaService zajeciaService) {
        this.zajeciaService = zajeciaService;
    }

    /**
     * GET /api/zajecia
     * Zwraca liste wszystkich zajec (dostepne dla kazdego ZALOGOWANEGO
     * uzytkownika - zarowno USER, jak i ADMIN - patrz SecurityConfig).
     */
    @GetMapping
    @Operation(summary = "Pobierz liste wszystkich zajec fitness w tygodniu")
    public ResponseEntity<List<Zajecia>> pobierzWszystkie() {
        return ResponseEntity.ok(zajeciaService.pobierzWszystkie());
    }

    /**
     * GET /api/zajecia/{id}
     * Zwraca szczegoly pojedynczych zajec.
     */
    @GetMapping("/{id}")
    @Operation(summary = "Pobierz szczegoly pojedynczych zajec po ID")
    public ResponseEntity<Zajecia> pobierzJedne(@PathVariable Long id) {
        return ResponseEntity.ok(zajeciaService.znajdzPoId(id));
    }

    /**
     * POST /api/zajecia
     * Tworzy nowe zajecia. TYLKO DLA ADMINA.
     * @PreAuthorize("hasRole('ADMIN')") to DODATKOWE zabezpieczenie na
     * poziomie metody (oprocz reguly w SecurityConfig) - tzw. "defense in
     * depth" (obrona w glab) - nawet gdyby ktos pomylil sie w konfiguracji
     * URL-i, ta adnotacja i tak zablokuje dostep dla nie-adminow.
     */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Utworz nowe zajecia (wymagana rola ADMIN)")
    public ResponseEntity<Zajecia> utworz(@Valid @RequestBody Zajecia zajecia) {
        Zajecia zapisane = zajeciaService.utworz(zajecia);
        return ResponseEntity.status(HttpStatus.CREATED).body(zapisane);
    }

    /**
     * DELETE /api/zajecia/{id}
     * Usuwa zajecia. TYLKO DLA ADMINA.
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Usun zajecia po ID (wymagana rola ADMIN)")
    public ResponseEntity<Void> usun(@PathVariable Long id) {
        zajeciaService.usun(id);
        return ResponseEntity.noContent().build();
    }
}
