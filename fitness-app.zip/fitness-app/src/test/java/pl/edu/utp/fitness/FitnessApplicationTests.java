package pl.edu.utp.fitness;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * ============================================================================
 * NAJPROSTSZY MOZLIWY TEST - tzw. "context load test".
 * ============================================================================
 * @SpringBootTest uruchamia CALY kontekst aplikacji Springa (tak jak przy
 * normalnym starcie programu), ale bez wystawiania go na zewnatrz.
 * Jesli w konfiguracji jest jakis blad (np. brakujacy bean, zle powiazania
 * miedzy klasami), ten test od razu to wykryje i nie przejdzie (FAIL) -
 * dlatego warto go miec jako "test dymny" (smoke test).
 */
@SpringBootTest
class FitnessApplicationTests {

    @Test
    void contextLoads() {
        // Metoda celowo pusta - sam fakt, ze Spring poprawnie zaladowal caly
        // kontekst aplikacji (wszystkie beany, konfiguracje, repozytoria),
        // bez rzucenia wyjatku, oznacza sukces tego testu.
    }
}
