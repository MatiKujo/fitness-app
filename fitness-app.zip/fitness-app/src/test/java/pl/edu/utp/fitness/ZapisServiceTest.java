package pl.edu.utp.fitness;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import pl.edu.utp.fitness.domain.StatusZapisu;
import pl.edu.utp.fitness.domain.Zajecia;
import pl.edu.utp.fitness.domain.Zapis;
import pl.edu.utp.fitness.exception.DuplicateZapisException;
import pl.edu.utp.fitness.exception.BrakUprawnienException;
import pl.edu.utp.fitness.repository.ZajeciaRepository;
import pl.edu.utp.fitness.repository.ZapisRepository;
import pl.edu.utp.fitness.service.ZapisService;

import java.time.DayOfWeek;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ============================================================================
 * TESTY ALGORYTMU KOLEJKOWANIA (listy rezerwowej) - najwazniejsze testy
 * w tym projekcie, poniewaz sprawdzaja "serce" calego zadania.
 * ============================================================================
 * @SpringBootTest       -> uruchamia caly, prawdziwy kontekst Springa
 *                          (prawdziwa baza H2 w pamieci, prawdziwe repozytoria).
 * @Transactional        -> KAZDY test jest opakowany w transakcje, ktora
 *                          jest AUTOMATYCZNIE WYCOFYWANA (rollback) po
 *                          zakonczeniu testu. Dzieki temu testy NIE
 *                          wplywaja na siebie nawzajem (kazdy zaczyna
 *                          z "czysta" baza) i nie trzeba nic recznie sprzatac.
 *
 * Scenariusz testowy (max = 2 miejsca na liscie glownej):
 *   1. Zapisuje sie "Anna"  -> lista GLOWNA (1/2 miejsc)
 *   2. Zapisuje sie "Piotr" -> lista GLOWNA (2/2 miejsc - limit osiagniety)
 *   3. Zapisuje sie "Kasia" -> limit osiagniety -> lista REZERWOWA, pozycja 1
 *   4. Zapisuje sie "Marek" -> lista REZERWOWA, pozycja 2
 *   5. "Anna" wypisuje sie z zajec (byla na liscie GLOWNEJ)
 *      -> oczekiwany wynik: "Kasia" (byla pierwsza w kolejce) automatycznie
 *         awansuje na liste GLOWNA, a "Marek" przesuwa sie na pozycje 1
 *         w kolejce rezerwowej.
 */
@SpringBootTest
@Transactional
class ZapisServiceTest {

    @Autowired
    private ZapisService zapisService;

    @Autowired
    private ZajeciaRepository zajeciaRepository;

    // Uzywamy repozytorium bezposrednio tylko w tescie, zeby wygodnie
    // pobrac "swiezy" stan zapisu z bazy po jego ID (w kodzie produkcyjnym
    // taki bezposredni dostep z pominieciem serwisu nie byłby zalecany).
    @Autowired
    private ZapisRepository zapisRepository;

    private Zajecia testoweZajecia;

    /**
     * Metoda oznaczona @BeforeEach wykonuje sie PRZED KAZDYM pojedynczym
     * testem w tej klasie - tworzymy tutaj swieze, "czyste" zajecia
     * z limitem 2 miejsc, na ktorych bedziemy testowac kolejkowanie.
     */
    @BeforeEach
    void przygotujDaneTestowe() {
        testoweZajecia = zajeciaRepository.save(
                new Zajecia("Testowa Joga", DayOfWeek.MONDAY, LocalTime.of(10, 0), 2)
        );
    }

    @Test
    @DisplayName("Pierwsze 2 osoby przy limicie 2 trafiaja na liste GLOWNA")
    void zapisDoLimituTrafiaNaListeGlowna() {
        Zapis zapisAnny = zapisService.zapiszSie(testoweZajecia.getId(), "anna");
        Zapis zapisPiotra = zapisService.zapiszSie(testoweZajecia.getId(), "piotr");

        assertEquals(StatusZapisu.GLOWNA, zapisAnny.getStatus());
        assertNull(zapisAnny.getPozycjaWKolejce());

        assertEquals(StatusZapisu.GLOWNA, zapisPiotra.getStatus());
        assertNull(zapisPiotra.getPozycjaWKolejce());
    }

    @Test
    @DisplayName("Osoba zapisujaca sie po zapelnieniu limitu trafia na liste REZERWOWA z pozycja 1")
    void zapisPoPrzekroczeniuLimituTrafiaNaListeRezerwowa() {
        zapisService.zapiszSie(testoweZajecia.getId(), "anna");   // GLOWNA (1/2)
        zapisService.zapiszSie(testoweZajecia.getId(), "piotr");  // GLOWNA (2/2) - limit osiagniety

        // "kasia" jest 3. osoba przy limicie 2 -> powinna trafic na rezerwe, pozycja 1
        Zapis zapisKasi = zapisService.zapiszSie(testoweZajecia.getId(), "kasia");

        assertEquals(StatusZapisu.REZERWOWA, zapisKasi.getStatus());
        assertEquals(1, zapisKasi.getPozycjaWKolejce());
    }

    @Test
    @DisplayName("Kolejne osoby na liscie rezerwowej dostaja rosnace pozycje w kolejce (1, 2, 3...)")
    void kolejneOsobyNaRezerwieMajaRosnacePozycje() {
        zapisService.zapiszSie(testoweZajecia.getId(), "anna");   // GLOWNA
        zapisService.zapiszSie(testoweZajecia.getId(), "piotr");  // GLOWNA

        Zapis kasia = zapisService.zapiszSie(testoweZajecia.getId(), "kasia"); // REZERWOWA #1
        Zapis marek = zapisService.zapiszSie(testoweZajecia.getId(), "marek"); // REZERWOWA #2

        assertEquals(1, kasia.getPozycjaWKolejce());
        assertEquals(2, marek.getPozycjaWKolejce());
    }

    /**
     * ========================================================================
     * NAJWAZNIEJSZY TEST W CALYM PROJEKCIE.
     * ========================================================================
     * Sprawdza dokladnie to, o co prosi tresc zadania:
     * "Testowanie przejscia z listy rezerwowej na liste glowna w przypadku
     *  zwolnienia miejsca."
     */
    @Test
    @DisplayName("Po wypisaniu osoby z listy glownej, pierwsza osoba z rezerwy awansuje na liste glowna")
    void wypisanieZListyGlownejPromujePierwszaOsobeZRezerwy() {
        // --- PRZYGOTOWANIE: zapelniamy liste glowna (limit = 2) i dodajemy 2 osoby na rezerwe ---
        Zapis zapisAnny = zapisService.zapiszSie(testoweZajecia.getId(), "anna");   // GLOWNA
        zapisService.zapiszSie(testoweZajecia.getId(), "piotr");                    // GLOWNA
        Zapis zapisKasi = zapisService.zapiszSie(testoweZajecia.getId(), "kasia");  // REZERWOWA, pozycja 1
        Zapis zapisMarka = zapisService.zapiszSie(testoweZajecia.getId(), "marek"); // REZERWOWA, pozycja 2

        // Upewniamy sie, ze stan poczatkowy jest taki, jak oczekujemy (sanity check).
        assertEquals(StatusZapisu.GLOWNA, zapisAnny.getStatus());
        assertEquals(StatusZapisu.REZERWOWA, zapisKasi.getStatus());
        assertEquals(1, zapisKasi.getPozycjaWKolejce());
        assertEquals(2, zapisMarka.getPozycjaWKolejce());

        // --- AKCJA: Anna (byla na liscie GLOWNEJ) wypisuje sie z zajec ---
        zapisService.wypiszSie(zapisAnny.getId(), "anna", false);

        // --- WERYFIKACJA WYNIKU ---

        // 1) Kasia (byla pierwsza w kolejce rezerwowej) powinna teraz byc
        //    na liscie GLOWNEJ, bez pozycji w kolejce.
        Zapis kasiaPoAwansie = pobierzAktualnyStan(zapisKasi.getId());
        assertEquals(StatusZapisu.GLOWNA, kasiaPoAwansie.getStatus(),
                "Kasia powinna awansowac na liste glowna po zwolnieniu miejsca");
        assertNull(kasiaPoAwansie.getPozycjaWKolejce(),
                "Osoba na liscie glownej nie powinna miec juz pozycji w kolejce");

        // 2) Marek powinien nadal byc na liscie rezerwowej, ale teraz na
        //    POZYCJI 1 (przesunal sie do przodu, bo Kasia "zwolnila" pozycje 1).
        Zapis marekPoPrzesunieciu = pobierzAktualnyStan(zapisMarka.getId());
        assertEquals(StatusZapisu.REZERWOWA, marekPoPrzesunieciu.getStatus(),
                "Marek powinien nadal byc na liscie rezerwowej");
        assertEquals(1, marekPoPrzesunieciu.getPozycjaWKolejce(),
                "Marek powinien przesunac sie na pozycje 1 w kolejce");

        // 3) Zapis Anny nie powinien juz istniec w bazie (zostal usuniety).
        assertTrue(zapisService.pobierzZapisyUzytkownika("anna").isEmpty(),
                "Zapis Anny powinien zostac usuniety po wypisaniu");

        // 4) Na liscie glownej nadal powinny byc dokladnie 2 osoby (Piotr + Kasia).
        assertEquals(2, zapisService.pobierzListeGlowna(testoweZajecia).size());

        // 5) Na liscie rezerwowej powinna zostac dokladnie 1 osoba (Marek).
        assertEquals(1, zapisService.pobierzListeRezerwowa(testoweZajecia).size());
    }

    @Test
    @DisplayName("Wypisanie osoby ze SRODKA listy rezerwowej poprawnie przeindeksowuje pozostale pozycje")
    void wypisanieZeSrodkaRezerwyPrzeindeksowujePozostalych() {
        zapisService.zapiszSie(testoweZajecia.getId(), "anna");   // GLOWNA
        zapisService.zapiszSie(testoweZajecia.getId(), "piotr");  // GLOWNA

        Zapis kasia = zapisService.zapiszSie(testoweZajecia.getId(), "kasia"); // REZERWOWA #1
        Zapis marek = zapisService.zapiszSie(testoweZajecia.getId(), "marek"); // REZERWOWA #2
        Zapis ola   = zapisService.zapiszSie(testoweZajecia.getId(), "ola");   // REZERWOWA #3

        // Marek (srodek kolejki, pozycja 2) wypisuje sie sam z siebie.
        zapisService.wypiszSie(marek.getId(), "marek", false);

        // Kasia powinna zostac na pozycji 1 (bez zmian).
        assertEquals(1, pobierzAktualnyStan(kasia.getId()).getPozycjaWKolejce());
        // Ola powinna przesunac sie z pozycji 3 na pozycje 2.
        assertEquals(2, pobierzAktualnyStan(ola.getId()).getPozycjaWKolejce());
    }

    @Test
    @DisplayName("Nie mozna zapisac sie 2 razy na te same zajecia (blad DuplicateZapisException)")
    void podwojnyZapisRzucaWyjatek() {
        zapisService.zapiszSie(testoweZajecia.getId(), "anna");

        // Druga proba zapisu tej samej osoby na te same zajecia powinna
        // zakonczyc sie wyjatkiem - assertThrows sprawdza, czy dany kod
        // rzeczywiscie rzuca oczekiwany typ wyjatku.
        assertThrows(DuplicateZapisException.class,
                () -> zapisService.zapiszSie(testoweZajecia.getId(), "anna"));
    }

    @Test
    @DisplayName("Standardowy uzytkownik nie moze wypisac cudzego zapisu (blad BrakUprawnienException)")
    void wypisanieCudzegoZapisuRzucaWyjatekBrakuUprawnien() {
        Zapis zapisAnny = zapisService.zapiszSie(testoweZajecia.getId(), "anna");

        // "piotr" probuje wypisac zapis nalezacy do "anny", nie bedac adminem (isAdmin = false)
        assertThrows(BrakUprawnienException.class,
                () -> zapisService.wypiszSie(zapisAnny.getId(), "piotr", false));
    }

    @Test
    @DisplayName("Administrator MOZE wypisac cudzy zapis")
    void adminMozeWypisacCudzyZapis() {
        Zapis zapisAnny = zapisService.zapiszSie(testoweZajecia.getId(), "anna");

        // "admin" wypisuje zapis "anny" - isAdmin = true, wiec operacja powinna sie udac
        // bez rzucenia wyjatku.
        assertDoesNotThrow(() -> zapisService.wypiszSie(zapisAnny.getId(), "admin", true));
        assertTrue(zapisService.pobierzZapisyUzytkownika("anna").isEmpty());
    }

    /**
     * Pomocnicza metoda - pobiera "swiezy" stan zapisu wprost z bazy danych
     * po jego ID. Jest to WAZNE w testach kolejki: obiekty Zapis pobrane
     * PRZED wykonaniem akcji (np. zapisAnny) moga w pamieci JVM nadal
     * pokazywac "stary" stan, dlatego po kazdej akcji pobieramy dane na nowo
     * bezposrednio z bazy, zeby miec pewnosc, ze sprawdzamy AKTUALNY stan.
     */
    private Zapis pobierzAktualnyStan(Long zapisId) {
        return zapisRepository.findById(zapisId).orElse(null);
    }
}
