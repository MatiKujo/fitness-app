# Fitness App - Rezerwacja zajęć z listą rezerwową

Projekt zaliczeniowy: system zapisów na zajęcia fitness z automatyczną
obsługą listy rezerwowej (kolejki).

## Co jest w środku

- **Baza danych**: encje `Zajecia` i `Zapis` (status: GLOWNA / REZERWOWA),
  H2 w pamięci (nic nie trzeba instalować).
- **Web UI (Thymeleaf)**: strona `/list` z listą zajęć w tygodniu i
  przyciskiem "Zapisz się" / "Wypisz się".
- **Algorytm kolejkowania**: `ZapisService` - gdy limit miejsc jest
  przekroczony, kolejna osoba trafia na listę rezerwową z pozycją w
  kolejce. Wypisanie się osoby z listy głównej automatycznie "wciąga"
  pierwszą osobę z rezerwy.
- **REST + Swagger**: pełne API pod `/api/zajecia` i `/api/zapisy`,
  dokumentacja pod `/swagger-ui.html`. Kluczowy endpoint z zadania:
  `POST /api/zapisy/{zapisId}/wypisz`.
- **Security**: Spring Security, rola USER (może się tylko zapisywać /
  wypisywać) i ADMIN (dodatkowo może tworzyć/usuwać zajęcia).
- **Testy**: `ZapisServiceTest` - m.in. test przejścia z listy rezerwowej
  na listę główną po zwolnieniu miejsca (dokładnie to, co wymaga treść
  zadania).

## Jak uruchomić

### Opcja 1: IntelliJ IDEA / Eclipse / VS Code (najprościej)

1. Rozpakuj ZIP.
2. Otwórz folder `fitness-app` jako projekt Maven (IDE samo wykryje
   `pom.xml` i pobierze zależności - potrzebny jest tylko dostęp do
   internetu przy pierwszym imporcie).
3. Uruchom klasę `FitnessApplication` (prawy klawisz -> Run), albo z
   terminala w IDE: `mvn spring-boot:run`.
4. Wejdź w przeglądarce na: **http://localhost:8080/list**

### Opcja 2: z linii komend (wymaga zainstalowanego Maven i JDK 17+)

```bash
cd fitness-app
mvn spring-boot:run
```

### Uruchomienie testów

```bash
mvn test
```

## Konta testowe (logowanie formularzem na stronie /list)

| login  | hasło     | rola          |
|--------|-----------|---------------|
| user   | user123   | USER          |
| admin  | admin123  | USER + ADMIN  |
| anna   | anna123   | USER          |
| piotr  | piotr123  | USER          |

Żeby ręcznie zobaczyć działanie listy rezerwowej: zajęcia "Joga" i
"Spinning" mają celowo bardzo mały limit (2 osoby) - zaloguj się na
kilku kontach (np. w oknach incognito) i zapisz więcej niż 2 osoby.

## Przydatne adresy po uruchomieniu

- `http://localhost:8080/list` - strona WWW (lista zajęć)
- `http://localhost:8080/swagger-ui.html` - dokumentacja / testowanie REST API
- `http://localhost:8080/h2-console` - podgląd bazy danych
  (JDBC URL: `jdbc:h2:mem:fitnessdb`, użytkownik: `sa`, hasło: puste)

## Struktura projektu

```
src/main/java/pl/edu/utp/fitness/
 ├── FitnessApplication.java      - klasa startowa
 ├── config/                      - SecurityConfig, OpenApiConfig, DataInitializer
 ├── domain/                      - encje: Zajecia, Zapis, enum StatusZapisu
 ├── repository/                  - interfejsy Spring Data JPA
 ├── service/                     - logika biznesowa (m.in. algorytm kolejki)
 ├── controller/                  - kontrolery REST + kontroler Web (Thymeleaf)
 └── exception/                   - własne wyjątki + globalny handler błędów

src/main/resources/
 ├── application.properties
 └── templates/list.html          - widok WWW

src/test/java/pl/edu/utp/fitness/
 ├── FitnessApplicationTests.java
 └── ZapisServiceTest.java        - testy algorytmu kolejkowania
```

## Uwaga

Kod jest bardzo obficie skomentowany po polsku (z myślą o osobie, która
dopiero uczy się Javy/Springa) - komentarze tłumaczą nie tylko *co* robi
dany fragment, ale też *dlaczego* tak jest napisany. Warto je przeczytać
przed egzaminem, bo tłumaczą całą logikę krok po kroku.
